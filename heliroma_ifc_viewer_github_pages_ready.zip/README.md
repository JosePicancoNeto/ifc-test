# Heliroma — IFC 3D Viewer (GitHub Pages ready)

## Deploy to GitHub Pages
1. Create a new GitHub repository (e.g. `heliroma-ifc-viewer`)
2. Upload these files to the repository root:
   - `index.html`
   - `Projeto_Objeto3D_Chat.ifc`
3. Go to **Settings → Pages**
4. Source: **Deploy from a branch**
5. Branch: **main** / **root**
6. Open your Pages URL (it may take ~1 minute to publish).

## Notes
- The viewer loads Three.js + IFC loader from CDN.
- If the IFC is very large, performance on mobile can be slow; later we can convert to GLB for faster loading.